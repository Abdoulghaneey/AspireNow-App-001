---------------------------------------------------------------------------------------------------
Follow the instructions before updating your single vendor eShop to Multivendor eShop:
---------------------------------------------------------------------------------------------------

1. Go to updater folder placed at root directory on multivendor code.

2. Open "updater\crud.php" this file.

3. In crud.php file you will some line that contains following code on line number 18,19,20,21:
        private $db_host = "localhost";  // Change as required
        private $db_user = "DB_USER";  // Change as required
        private $db_pass = "DB_PASSWORD";  // Change as required
        private $db_name = "DB_NAME";    // Change as required

4. Change this DB_USER, DB_PASSWORD, DB_NAME accroding to your server. And save it.

5. Set this updater fodler on your single vendor root directory. Now run the updater script by this following URL:
        BASE_URL/updater/updater.php

                    or

        DOMAIN_URL/updater/updater.php

